# chime-webhook-python

## Setup
1. Create a webhook in a Chime room that you have admin privileges for
2. Enter the URL into [line 5](https://github.com/ckuzma/chime-webhook-python/blob/master/send_message.py#L5) of `send_message.py`

## Send a message
`python3 send_message.py "This is a demo message"`
